/**
 * @file course.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Appends student to course by entering the students into a list, if said list is empty then it will start it using calloc, if not it will change the size of the list using realloc
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student) 
{
  course->total_students++; 
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); // If list is empty run calloc
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //  otherwise it will resize using realloc
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints out the course name, course code, total amount of student in the course, and who the students are
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name); 
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]); // Each students name being printed 
}

/**
 * @brief Returns the student in the course who has the highest average in the course
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) // finds all students averages and returns back the average of the highest student
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief returns list of students that have a passing grade 
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; // checks if average of students is greater or equal to the passing mark and adds to count
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++) 
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];  // counts the amount of students passing in the course
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}